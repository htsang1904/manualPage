<?php $strings = "tinyMCE.addI18n({en:{
theme_shortcodes:{desc : 'Add a Custom Shortcode'},}});";
?>