tinymce.addI18n('en', {
  'Add a Custom Shortcode': 'Add a Custom Shortcode'
});